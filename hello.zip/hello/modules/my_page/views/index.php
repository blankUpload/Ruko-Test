<!--Page Title-->
<h1 class="page-title"><?php echo 'Import Excel Spreadsheets.' ?> </h1>

<!--Tell Time (UnixtimeStamp)-->
<h5><?php echo "Time: " . date("d/m/y") . " | " . date("h:i") ."<br>"; ?></h5>

<!--Linked Page Buttons-->
<div class="btn-group">
    <a class="btn btn-primary" href="<?php echo url_for('dashboard/dashboard'); ?>">
        <i class="fa fa-home"></i> Home
    </a>
    <a class="btn btn-primary" style="background-color:#005b96; border-color:#005b96;" href="<?php echo url_for('configuration/application'); ?>">
        <i class="fa fa-gear"></i> Configuration
    </a>
    <a class="btn btn-primary" style="background-color:#03396c; border-color:#03396c;" href="<?php echo url_for('tools/about'); ?>">
        <i class="fa fa-info"></i> About
    </a>
</a>
</div>
<hr> <!--line-->

<h4><b>Introduction</b></h4>
<p>I enjoyed coding every bit of this page as it helped reinforce my 
    understanding of PHP and the vast variations and combinations that come with it.

<br>
    The page is split into two segments: a demonstration section, where a couple of core PHP 
    concepts are shown, and an Excel import page, which focuses on 
    handling imported data and Ruko’s core features.
</p>
<hr> <!--line-->

<h4><b>Resources Used</b></h4>
<p><b>
    <a href="https://www.w3schools.com/php/default.asp"> w3schools' PHP</a>
<br>
    <a href="https://www.w3schools.com/html/default.asp"> w3chools' HTML</a>
<br>
    <a href="https://www.w3schools.com/php/php_oop_constructor.asp"> w3chools' OOPs</a>
<br>
    <a href="https://stackoverflow.com/questions"> stackOverFlow</a>
<br>
    <a href="https://fontawesome.com/icons"> fontAwesome</a>
</b></p>
<hr> <!--line-->

<!--Showcase-->

<!--Function with Random Generation-->
<h4><b>Function Showcase</b></h4>
<?php
function RNG_years()
{
    //Holds the years 2000 - 2026 (An Array of integers);
    $years = range(2000,2026);
    //Picks a random integer using array_rand
    $randomYears = $years [array_rand($years)];
    //Prints out a string alongside returning $randomYears
    echo "<p> Did you know I was a fan of the year  <b>$randomYears!</b></p>";
    //Ruko's way of printing infomation about the varible
    print_rr ($randomYears);
}

//Prompts the RNG_years() Function
RNG_years();
?>
<hr>

<!--Classes and instances-->
<h4><b>Class Showcase</b></h4>
<?php
//defines "Project" as a class
class Project
{
    //creates a public varible named $title
    public $title;
    //A constructor that runs automatically when a new project is made
    public function __construct($title)
    {
        //refers to the objects property
        $this->title = $title;
    }

    //function within a class
    public function getInfo()
    {
        //access the property stored in the object, while returning a string
        return "Project title: " . $this->title;
    }
}

function Instance()
{
    //creates a new object
    $project = new Project("Webpage Redesign");
    //calls the getInfo function
    echo "<p>Class Instance | " . $project->getInfo() . "</p>";
    print_rr ($project);
}

//calls the function
Instance();
?>

<hr>

<!--Simple Loop-->
<h4><b>Simple Loop</b></h4>
<?php
function loop()
{
    echo "<p>Output:</p>";
    //creates a bulletpoint
    echo "<ul>";

    //loop starts at 1 and runs while $i is less or equal to 5
    for ($i=1 ; $i<=5 ; $i++)
        {
            echo "<li>Number $i</li>";
        }

    //creates a bulletpointed list
    echo "</ul>";
    print_rr ($i);
}

loop()
?>

<hr>

<?php
//Import Table
require(component_path('items/load_items_listing.js'));
//Excel Guide Button
echo '<a class="btn btn-primary" href="javascript: open_dialog(\'' . url_for('hello/my_page/info') . '\')">' . "Infomation" . '</a>';
?>

<HTML>
<body>
<!--Import Excel Spreadsheet Button-->
<a onclick="open_dialog('http://localhost/3.6.3/index.php?module=items/import&amp;path=21')" class="btn btn-default link-to-modalbox" title="Import"><i class="fa fa-upload"></i></a>

<!--Search -->
<form id="entity_items_listing66_21_search_form" class="navbar-search listing-search-form" onsubmit="load_items_listing('entity_items_listing66_21',1); return false;">
    
    <div class="input-group input-medium">
    
      <div class="input-group-btn">
  			<button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" aria-expanded="false"><i class="fa fa-angle-down"></i></button>
  			<div class="dropdown-menu hold-on-click dropdown-checkboxes" role="menu">
  				<label><div class="checker" id="uniform-entity_items_listing66_21_use_search_fields"><span class="checked"><input name="entity_items_listing66_21_use_search_fields[]" id="entity_items_listing66_21_use_search_fields" value="158" type="checkbox" class="entity_items_listing66_21_use_search_fields" checked="checked"></span></div>Name</label><label><div class="checker" id="uniform-entity_items_listing66_21_use_search_fields"><span><input name="entity_items_listing66_21_use_search_fields[]" id="entity_items_listing66_21_use_search_fields" value="160" type="checkbox" class="entity_items_listing66_21_use_search_fields"></span></div>Description</label><label class="divider"></label>
  			<label><div class="checker" id="uniform-entity_items_listing66_21_search_in_all"><span><input name="entity_items_listing66_21_search_in_all" id="entity_items_listing66_21_search_in_all" value="1" type="checkbox"></span></div>Disable filters</label>
  			<label><div class="checker" id="uniform-entity_items_listing66_21_search_type_and"><span><input name="entity_items_listing66_21_search_type_and" id="entity_items_listing66_21_search_type_and" value="1" type="checkbox"></span></div>Search all words</label>
  			<label><div class="checker" id="uniform-entity_items_listing66_21_search_type_match"><span><input name="entity_items_listing66_21_search_type_match" id="entity_items_listing66_21_search_type_match" value="1" type="checkbox"></span></div>Exact match</label>
  			<label class="divider"></label><input name="entity_items_listing66_21_search_reset" id="entity_items_listing66_21_search_reset" value="" type="hidden"><label><div class="checker" id="uniform-entity_items_listing66_21_search_in_comments"><span><input name="entity_items_listing66_21_search_in_comments" id="entity_items_listing66_21_search_in_comments" value="1" type="checkbox"></span></div>Search in comments</label><label class="divider"></label>
          <label><a onclick="open_dialog('http://localhost/3.6.3/index.php?module=dashboard/search_help')" class=" link-to-modalbox">Search Help</a></label>
  			</div>
  		</div>
        	
  		<input name="entity_items_listing66_21_search_keywords" id="entity_items_listing66_21_search_keywords" value="" type="text" placeholder="Search" class="form-control input-medium">
  		<span class="input-group-btn">  			
        <button title="Search" class="btn btn-info"><i class="fa fa-search"></i></button>
  		</span>
  	</div>
  </form>

<br>
<br>

<!--Load Table-->
<input name="entity_items_listing66_21_order_fields" id="entity_items_listing66_21_order_fields" value="" type="hidden">
<script>
    $(function ()
    {
        load_items_listing('entity_items_listing66_21',1);
    });
</script> 
<div id="entity_items_listing66_21" class="entity_items_listing entity_items_listing_loading" style="opacity: 1;"></div>

</body>
</HTML>
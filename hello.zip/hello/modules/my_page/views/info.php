<!--Header-->
<?php echo ajax_modal_template_header("Excel Infomation") ?>

<html>
<body>
  
  <br>
<!--Description-->
  <h4 style="text-align:center;"><b>What is an Excel Document?</b></h4>
  <p style="text-align:center;">An Excel spreadsheet is a digital workspace built from rows and columns, 
    where each cell can store data. These cells can be linked so that calculations 
    update automatically when data changes, 
    making it more than just a place to write information down.
  </p>

  <h4 style="text-align:center;"><b>What is it used for?</b></h4>

  <p style="text-align:center;">Excel is commonly used because it saves time and helps keep 
    information organised and maintained. It can quickly perform calculations, 
    sort through data, and present everything clearly, 
    making it easier to understand patterns and manage tasks.</p>
  </p>

  <h4 style="text-align:center;"><b>Allowed Extensions</b></h4>
  <p style="text-align:center;"><b>.xls | .xlsx
  </b></p>

<hr>

<!--Close Button-->
<p align="centre">
<button type="button" style="margin-left:auto; margin-right:auto; display:block" class="btn btn-default btn-close" data-dismiss="modal">Close</button>

</body>
</html>